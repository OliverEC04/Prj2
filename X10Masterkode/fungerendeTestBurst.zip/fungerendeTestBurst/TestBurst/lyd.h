/*
 * lyd.h
 *
 * Created: 17-05-2023 11:57:43
 *  Author: Karl-Emil
 */ 


#ifndef LYD_H_
#define LYD_H_
void initLyd();
void playLockedSound();
void playUnlockedSound();

#endif /* LYD_H_ */