/*
 * DE2.h
 *
 * Created: 15-05-2023 10:51:18
 *  Author: Karl-Emil
 */ 


#ifndef DE2_H_
#define DE2_H_

#include <avr/io.h>
#include <stdbool.h>
bool boardUnlocked();


#endif /* DE2_H_ */